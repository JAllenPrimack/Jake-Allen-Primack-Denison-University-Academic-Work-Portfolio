#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Allen Primack
October 24, 2018
IndividualProject4_Polling.py
This program investigates how polling size affects accuracy of the polling results. 
This program determines emperically how large a sample needs to be to reliably represent the sentiments of a large population.
"""

import random;
import matplotlib.pyplot as plt;


def poll(percentage, pollSize):
    '''
    This function simulates the polling of "pollsize" individuals from a large population from which the
    given percentage (between 0 and 100), will respond "yes".
    Parameters:
        percentage - a value between 0 and 100 
        pollSize- number of individuals chosen from the large population- aka, the sample size
    RETURN VALUE:
        numOfActualYes/size * 100: the percentage (between 0 and 100), of the poll that actually responded
        "yes".
    '''
    numOfYes = round((percentage/100) * pollSize)
    numOfActualYes = 0;
    people = []
    for i in range(pollSize):
        if (i >= numOfYes):
            people.append(0)
        else:
            people.append(1)
    for j in range(pollSize):
        vote = random.choice(people)
        if (vote == 1):
            numOfActualYes +=1
    
    return (numOfActualYes/pollSize) * 100

def Min(values):
    '''
    This function takes the a list of numbers as inputs and returns the smallest value in that list
    PARAMETERS:
        values- given numbers in the list
    RETURN VALUE:
        the smallest number in the list (minValue)
    '''
    minValue = values[0]

    for value in values:
        if (value < minValue):
            minValue = value
    return minValue

def Max(values):
    '''
    This function takes a list of numbers as inputs and returns the largest value in that list
    PARAMETERS:
        values- given numbers in the list
    RETURN VALUE:
        the largest number in the list (maxValue)
    '''

    maxValue = values[0]

    for value in values:
        if (value > maxValue):
            maxValue = value
    return maxValue

def pollExtreme(percentage, pollSize, trials):
    pollResult = []
    '''
    This function investigates how much variation there can be in a poll of a particular size. 
    It builds a list of trials poll results by calling poll(percentage,pollSize) "trials" number of times.
    The pollResult variable is the list of poll results.
    Parameters:
        percentage - a value between 0 and 100 
        pollSize- number of individuals chosen from the large population- aka, the sample size
    RETURN VALUE:
        Min(pollResult), Max(pollResult)- Returns the minimum and maximum percentages in the list
    '''
    for i in range(trials):
        pollResult.append(poll(percentage, pollSize))
    
    return Min(pollResult), Max(pollResult)

def plotResult(percentage, minPollSize, maxPollSize, step, trials):
    
    percentY = []
    percentmin_y = []
    '''
    This function investigates how increasing poll sizes increase the variation of the poll results by plotting
    the minimum and maximum values in the list.
    Parameters:
        percentage - a value between 0 and 100 
        minpollSize- Minimum number of individuals chosen from the large population
        maxpollSize- Maximum number of individuals chosen from the large population
        step: the degree of incrementation
        trials: The number of times this experiment is run
    RETURN VALUE:
        pollExtreme(percentage, pollSize, trials)
    '''
    polsizeX = list(range(minPollSize, maxPollSize, step))
    for pollSize in polsizeX:
        minPer, maxPer = pollExtreme(percentage, pollSize, trials)
        percentY.append(maxPer)
        percentmin_y.append(minPer)
    plt.plot(polsizeX, percentY, label='Maximum X')
    plt.plot(polsizeX, percentmin_y, label='Minimum X')
    plt.ylabel('Percentage of yes')
    plt.xlabel("Poll Size")
    plt.title("Effect of Polling Size on Accuracy")
    plt.legend()
    plt.show()
    


    
        
def main():
    plotResult(30, 10, 1000, 10, 100)   

main()